
public class Application {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String path = "C:/Users/S�bastien/Documents/Eclipse/AABRI/src/listeABRI.txt";
		String savePath = "C:/Users/S�bastien/Documents/Eclipse/AABRI/src/saveListeABRI.txt";
		
		AABRI abri = new AABRI(path);
		//abri.parcoursPrefixe();
		//abri.WriteFile(savePath);
	}
}
